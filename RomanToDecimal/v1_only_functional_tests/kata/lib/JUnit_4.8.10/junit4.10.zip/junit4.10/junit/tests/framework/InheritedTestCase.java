package junit.tests.framework;

/**
 * Test class used in SuiteTest
 */
public class InheritedTestCase extends OneTestCase { 
	public void test2() {
	}
}