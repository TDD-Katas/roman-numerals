/**
 * Tests for the JUnit v3.x runner functionality.
 */
package junit.tests.runner;